package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;


import com.cts.dto.User;
import com.cts.util.DBConnection;

public class UserDAO {

	
	

	
	/*public List<User> getAllUsers() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con = DBConnection.getConnection();
		List<User> userList = new ArrayList<>();
		User User = new User(null, null);
		
		try {
			PreparedStatement ps = con.prepareStatement("select NAME,PASSWORD from USER_TABLE");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				//User.setId(rs.getInt(1));
				User.setUsername(rs.getString(1));
				
				User.setPassword(rs.getString(2));
	
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return userList;

	}*/
	@SuppressWarnings("resource")
	public boolean add(User user) throws SQLException, ClassNotFoundException {
		
		
        Connection con = DBConnection.getConnection();
        PreparedStatement ps = null;
        ResultSet rs=null;
        
        int i=0;
        try {
        	ps=con.prepareStatement("select user_seq.nextval from dual");
        	rs=ps.executeQuery();
        	rs.next();
        
        	
            ps = con.prepareStatement("insert into user_table(name,password) values(?,?)");
          
            ps.setString(1,user.getUsername());


            ps.setString(2, user.getPassword());


            
            i = ps.executeUpdate();
          
        }catch(Exception e) {
            e.printStackTrace();
        }
       
        finally {
          
         ps.close();
         con.close();
   }
        if(i>0)
        	return true;
        else
        	return false;
        
        
   }
	


	public    User validateUser(String uname, String upwd) throws ClassNotFoundException, SQLException {
		Connection conn=null;
        PreparedStatement st=null;
        ResultSet rs=null;
       // boolean result=false;
        User u=null;
        try
        {
                        conn=DBConnection.getConnection();
                        st=conn.prepareStatement("select * from user_table where name=? and password=?");
                        st.setString(1, uname);
                        st.setString(2, upwd);
                        rs=st.executeQuery();
                        if(rs.next())
                        {
                        	u=new User(uname, upwd);
                        	
                        	u.setUsername(rs.getString(1));
                        
                        	u.setPassword(rs.getString(2));
                        
                                       
                        }
                        
        }
        catch(Exception e)
        {
                        e.printStackTrace();
        }
        return u;

	}



}
