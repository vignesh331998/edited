package com.cts.controller;


import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.cts.bo.UserBO;
import com.cts.dto.User;

public class UserControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if (action.equals("Register")) {
			registrationProcess(request, response);

		}

		if (action.equals("Login")) {
			try {
				processLogin(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}


	}

	private void processLogin(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {

		

        User user=null;
		//boolean result = false;

		HttpSession session=request.getSession();
		try {

			
			 String uname = request.getParameter("uname");
		
				String upwd = request.getParameter("upwd");
				UserBO userbo=new UserBO();
				
				 user=userbo.validateUser(uname, upwd);
				RequestDispatcher dispatcher=null;
			
				if(user!=null)
				{
					dispatcher=request.getRequestDispatcher("planlist.jsp");
					session.setAttribute("user", user);
					dispatcher.forward(request, response);

				}
				else
				{
					dispatcher=request.getRequestDispatcher("Login.jsp");
				    request.setAttribute("msg","Invalid username/password");
					dispatcher.forward(request, response);
				}
			}
			

		catch (ServletException | IOException e) {
			e.printStackTrace();
		}

	}

	private void registrationProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("uname");
		String pass = request.getParameter("upwd");
		        
		
		UserBO userBo = new UserBO();
		RequestDispatcher dispatcher=null;
		boolean b;
		try {
			b = userBo.validateUser(name, pass) != null;
			if(b)
			{
				dispatcher=request.getRequestDispatcher("Login.jsp");
				dispatcher.forward(request, response);
			}
			 
	
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}


	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
