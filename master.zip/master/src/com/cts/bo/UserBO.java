package com.cts.bo;

import java.sql.SQLException;
//import java.util.List;

import com.cts.dao.UserDAO;

import com.cts.dto.User;



public class UserBO {

	
	public User validateUser(String uname,String upwd) throws ClassNotFoundException, SQLException
	{
	       UserDAO userdao=new UserDAO();
	       User user=userdao.validateUser(uname, upwd);
	       return user;
	}
	public boolean add(User user) throws ClassNotFoundException, SQLException {
		
		UserDAO userdao = new UserDAO();
		return userdao.add(user);
		
	}	
	/*public List<User> getAllUsers() throws ClassNotFoundException, SQLException {
		UserDAO userdao = new UserDAO();
		return userdao.getAllUsers();		
	}*/
	
	
}
