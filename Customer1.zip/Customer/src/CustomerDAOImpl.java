import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomerDAOImpl implements CustomerDAO {

	static Connection con;
	static PreparedStatement ps;
	@Override
	public int insertCustomer(Customer c) {
		int i=0;
		try {
			con =DBConnection.getConnection();
			ps=con.prepareStatement("insert into customer values (?,?)");
			ps.setString(1,c.getName());
			ps.setString(2,c.getAge());
			i=ps.executeUpdate();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return i;
	}

	@Override
	public Customer getCustomer(String name, String age) {
		Customer c=new Customer();
	try {
		con =DBConnection.getConnection();
		ps=con.prepareStatement("select * from customer where name=? and age=?");
		ps.setString(1,name);
		ps.setString(2,age);
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			c.setName(rs.getString(1));
			c.setAge(rs.getString(2));
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return c;
	}

}
