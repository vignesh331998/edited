

import java.sql.Connection;
import java.sql.DriverManager;



public class DBConnection {
	


	static Connection con=null;
	
	public static Connection getConnection()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/database1", "root", "Vignesh@3398");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
		
	}
	
}

//jdbc:oracle:thin:@//localhost:1521/xe