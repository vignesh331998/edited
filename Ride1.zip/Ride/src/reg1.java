

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;



import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class reg1
 */
@WebServlet("/reg1")
public class reg1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public reg1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		String location=request.getParameter("location");
		String startdate=request.getParameter("startdate");
		String enddate=request.getParameter("enddate");
		Connection con=DBConnection.getCon();
		try {
			String sql="insert into detail1 values('"+location+"','"+startdate+"','"+enddate+"')";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.executeQuery();
			request.getRequestDispatcher("display.jsp").forward(request, response);
			out.println("success");
			con.close();
			}
		catch(Exception e)
		{
			System.out.println(e);
		}
		

	}

}
